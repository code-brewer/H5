import Vue from 'vue'

import VueRouter from 'vue-router'
import VueResource from 'vue-resource'

Vue.use(VueRouter)
Vue.use(VueResource)

//Vue.http.options.emulateJSON = true;

export var router = new VueRouter()

router.map({
    '/': {
        component: require('./views/home.vue')
    },
    '/home': {
    	component: require('./views/home.vue')
    }
})

router.redirect({
    '*': '/'
})

init = function() {
    router.start(require('./views/App.vue'), 'app')
}
