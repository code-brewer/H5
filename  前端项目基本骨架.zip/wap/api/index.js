
var api = {};

function putApi(name, url, code, method, contentType) {
	if(!method) {
		method = 'post';
	}
    api[name] = (context, body, fun) => {
        var data = getCreds(code, body);
        context.$http[method](url, data , (back) => {
            if (fun)
                fun(back)
        }).error((err)=> {
            if(fun) {
                fun(err);
            }
        })

    }
}

function getCreds(proNo, body) {
    return {
        base: {
            reqTime: new Date().format('yyyyMMddHHmmss'),
            proNo: proNo,
        },
        body: body
    }
}

// 示例
putApi('signList', basePath + 'weixin/signList', '10000');

export default api;